public class IqCountry {
    int place;
    String country;
    int iq;
    public IqCountry(String country, int place, int iq){
        this.place = place;
        this.country = country;
        this.iq = iq;
    }
}
